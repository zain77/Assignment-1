from Tkinter import *
import MySQLdb
import tkMessageBox

#connect to database
db = MySQLdb.connect ("localhost", "root", "", "quizzles")
#setup the cursor
cursor = db.cursor()

def insert_quiz(qtitle,qdesc,qtime,ctitle,var,qname,a1,a2,a3,a4,acorr):
    
    sql="INSERT INTO question (q_title, q_desc, q_time, q_course, q_type, q_name, a1, a2, a3, a4,a_corr) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
    cursor.execute(sql, (qtitle,qdesc,qtime,ctitle,var,qname,a1,a2,a3,a4,acorr))

    status=tkMessageBox.askyesno("NEXT","Do you want to submit another question?")
    if (status):
        createQuiz()
    else:
        status=tkMessageBox.askyesno("NEXT","Do you want to create another quiz?")
        if (status):
            createQuiz()
        else:
            root.destroy()
            cursor.close()
            db.close()
            exit

    

def startQuiz(qtitle, qdesc, qtime, ctitle, var):
    if var==1:
        l1 = Label(root, text="Type the MCQ question: ")
        e1 = Entry(root)
        l2 = Label(root, text="Option 1: ")
        e2 = Entry(root)
        l3 = Label(root, text="Option 2: ")
        e3 = Entry(root)
        l4 = Label(root, text="Option 3: ")
        e4 = Entry(root)
        l5 = Label(root, text="Option 4: ")
        e5 = Entry(root)
        l6 = Label(root, text="Correct answer: ")
        e6 = Entry(root)

        l1.grid(row=12, column=0, sticky="E")
        e1.grid(row=12, column=1)
        l2.grid(row=13, column=0, sticky="E")
        e2.grid(row=13, column=1)
        l3.grid(row=14, column=0, sticky="E")
        e3.grid(row=14, column=1)
        l4.grid(row=15, column=0, sticky="E")
        e4.grid(row=15, column=1)
        l5.grid(row=16, column=0, sticky="E")
        e5.grid(row=16, column=1)
        l6.grid(row=17, column=0, sticky="E")
        e6.grid(row=17, column=1)

        b1 = Button(root, text="Submit question", command=lambda: insert_quiz(qtitle, qdesc, qtime, ctitle,var,e1.get(),e2.get(),e3.get(),e4.get(),e5.get(),e6.get()))
        b1.grid(row=18, columnspan=2)

    elif var==2:
        l1 = Label(root, text="Type the T/F question: ")
        e1 = Entry(root)
        l2 = Label(root, text="Option 1: ")
        e2 = Entry(root)
        l3 = Label(root, text="Option 2: ")
        e3 = Entry(root)
        e4=0
        e5=0
        l6 = Label(root, text="Correct answer: ")
        e6 = Entry(root)

        l1.grid(row=12, column=0)
        e1.grid(row=12, column=1)
        l2.grid(row=13, column=0)
        e2.grid(row=13, column=1)
        l3.grid(row=14, column=0)
        e3.grid(row=14, column=1)
        l6.grid(row=15, column=0)
        e6.grid(row=15, column=1)

        b1 = Button(root, text="Submit question", command=lambda: insert_quiz(qtitle, qdesc, qtime, ctitle,var,e1.get(),e2.get(),e3.get(),e4,e5,e6.get()))
        b1.grid(row=18, columnspan=2)
        
    elif var==3:
        l1 = Label(root, text="Type the numerical question: ")
        e1 = Entry(root)
        e2=0
        e3=0
        e4=0
        e5=0
        l6 = Label(root, text="Correct answer: ")
        e6 = Entry(root)

        l1.grid(row=12, column=0)
        e1.grid(row=12, column=1)
        l6.grid(row=14, column=0)
        e6.grid(row=14, column=1)
        
        b1 = Button(root, text="Submit question", command=lambda: insert_quiz(qtitle, qdesc, qtime, ctitle,var,e1.get(),e2,e3,e4, e5, e6.get()))
        b1.grid(row=18, columnspan=2)


def tselectQuiz(qtitle,qdesc,qtime,ctitle):
    #Label(root, text=qtitle).grid(row=4, column=0)
    #Label(root, text=qdesc).grid(row=4, column=1)
    #Label(root, text=qtime).grid(row=4, column=2)
    #Label(root, text=ctitle).grid(row=4, column=3)
    
            
    Label(root, text="Select the type of question").grid(row=5, column=0, columnspan=2)
    
    track=IntVar() #object of IntVar class
    track=1

    val1=1
    val2=2
    val3=3
    Radiobutton(root, text="Add an MCQ", value=val1, variable=track, command=lambda: startQuiz(qtitle, qdesc, qtime, ctitle,val1)).grid(row=6, column=0, sticky="W")
    Radiobutton(root, text="Add T/F", value=val2, variable=track, command=lambda: startQuiz(qtitle, qdesc, qtime, ctitle,val2)).grid(row=7, column=0, sticky="W")
    Radiobutton(root, text="Add a numerical", value=val3, variable=track, command=lambda: startQuiz(qtitle, qdesc, qtime, ctitle,val3)).grid(row=8, column=0, sticky="W")


def createQuiz():
    global root
    root = Tk()
    root.geometry("600x400")
    root.title("TEACHER'S MENU")

    l1 = Label(root, text="Create a quiz")
    l2 = Label(root, text="Title of the Quiz: ")
    l3 = Label(root, text="Description of the Quiz: ")
    l4 = Label(root, text="Time for the Quiz: ")
    l5 = Label(root, text="Title of the Course: ")
    e2 = Entry(root)
    e3 = Entry(root)
    e4 = Entry(root)
    e5 = Entry(root)

    l1.grid(columnspan=2)
    l2.grid(row=1, column=0, sticky="E")
    l3.grid(row=2, column=0, sticky="E")
    l4.grid(row=3, column=0, sticky="E")
    l5.grid(row=4, column=0, sticky="E")
    e2.grid(row=1, column=1)
    e3.grid(row=2, column=1)
    e4.grid(row=3, column=1)
    e5.grid(row=4, column=1)
    
    b1 = Button(root, text="Proceed", command=lambda: tselectQuiz(e2.get(),e3.get(),e4.get(),e5.get()))
    b1.grid(row=2, column=3)

    b2 = Button(root, text="Exit")
    b2.bind("<Button-1>", exit)
    b2.grid(row=3, column=3)

    root.mainloop()





