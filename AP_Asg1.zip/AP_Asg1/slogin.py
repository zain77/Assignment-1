from Tkinter import *
import MySQLdb
import ssignup
import student
import tkMessageBox

#connect to database
db = MySQLdb.connect ("localhost", "root", "", "quizzles")
#setup the cursor
cursor = db.cursor()


def read_db(n,p):

    sql = "SELECT * FROM students"
    cursor.execute(sql)
    data = cursor.fetchall()

    count=0

    for row in data:
        if (n==row[1]):
            if(p==row[2]):
                count += 1
    if (count>0):
        student.selectQuiz(n,p)
    elif (count<=0):
        tkMessageBox.showerror("LOGIN FAILED","PLEASE SIGNUP FIRST")

    cursor.close()
    db.close()
    exit
    
def login(event):
    root = Tk()
    root.geometry("400x200")
    root.title("LOGIN")
    
    l0 = Label(root, text="Please enter your username and password")
    l1 = Label(root, text="USERNAME: ")
    e1 = Entry(root) #take input from user
    l2 = Label(root, text="PASSWORD: ")
    e2 = Entry(root, show="*") #take input from user but hide password

    l0.grid(row=0, columnspan=2)
    l1.grid(row=1, column=0, sticky=E)
    l2.grid(row=2, column=0, sticky=E)
    e1.grid(row=1, column=1)
    e2.grid(row=2, column=1)

    c = Checkbutton(root, text="Keep me logged in") # create check button
    c.grid(row=3, columnspan=2)

    b1 = Button(root, text="Signup", fg="blue", bg="white", # create signup button
                command=lambda: ssignup.signup())
    b1.grid(row=4, column=0)
    b2 = Button(root, text="Login", fg="darkgreen", bg="white",  # create login button
                command=lambda: read_db(e1.get(),e2.get())) 
    b2.grid(row=4, column=1)

    root.mainloop()
