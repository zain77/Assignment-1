from Tkinter import * #import everything from Tkinter
import slogin
import tlogin


root = Tk() #create a blank window
root.geometry("200x100")

root.title("MAIN")

l1 = Label(root, text="Welcome to the Quiz App")

b1 = Button(text="Student", fg="lightblue" ,bg="white") # a student button 
b2 = Button(text="Teacher", fg="red" ,bg="white") # a teacer button

# when button pressed, login screen opened

b1.bind("<Button-1>", slogin.login)
b2.bind("<Button-1>", tlogin.login)

#display the label and buttons
l1.grid(row=0, columnspan=2) #join two columns
b1.grid(row=1, column=0) #this button will appear in the leftmost position
b2.grid(row=1, column=1) #this button will appear in the rightmost position


root.mainloop() #mainloop puts the code in an infinite loop
                #and displays the window until you press the close button
