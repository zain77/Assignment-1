from Tkinter import *
import MySQLdb
import tkMessageBox

#connect to database
db = MySQLdb.connect("localhost", "root", "", "quizzles")
#setup the cursor
cursor = db.cursor()



def checkAns(o,a):
    global marks
    global n
    global p
    
    #print "correct option", o
    #print "user answer", a
    if (o==a):
        Label(rootc, text="Correct answer. Please close all windows to access the next question").grid(row=13,column=0)
        marks += 1
    else:
        Label(rootc, text="Wrong answer. Please close all windows to the access next question").grid(row=13,column=0)
    #print "marks:" ,marks
    Label(rootc, text="Total marks obtained: %s" %marks).grid(row=14,column=0)
    
    sql = "UPDATE students SET s_marks = %s WHERE s_uname=%s AND s_paswd=%s"
    cursor.execute(sql, (marks,n,p))



def answerQuiz(t,c):
    global marks
    
    sql = "SELECT * FROM question WHERE q_title=%s AND q_course=%s"
    cursor.execute(sql, (t,c))
    data = cursor.fetchall()

    
    for row in data:
        global rootc
        rootc= Tk()
    
        Label(rootc, text=row[1]).grid(row=5, column=0)
        Label(rootc, text=row[4]).grid(row=5, column=1)

        if (row[5]==1):
            Label(rootc, text="Question: %s" % (row[6])).grid(row=6, column=0, sticky="W")
            Label(rootc, text="A: %s" % (row[7])).grid(row=7, column=0,sticky="W")
            Label(rootc, text="B: %s" % (row[8])).grid(row=8, column=0, sticky="W")
            Label(rootc, text="C: %s" % (row[9])).grid(row=9, column=0, sticky="W")
            Label(rootc, text="D: %s" % (row[10])).grid(row=10, column=0, sticky="W")
        elif (row[5]==2):
            Label(rootc, text="Question: %s" % (row[6])).grid(row=6, column=0, sticky="W")
            Label(rootc, text="A: %s" % (row[7])).grid(row=7, column=0, sticky="W")
            Label(rootc, text="B: %s" % (row[8])).grid(row=8, column=0, sticky="W")
        elif (row[5]==3):
            Label(rootc, text="Question: %s" % (row[6])).grid(row=6, column=0, sticky="W")
        else:
            tkMessageBox.showerror("Good News, there is no quiz today :D")

        o=row[11]
        ans = Entry(rootc)
        ans.grid(row=11, column=0, sticky="W")


        Button(rootc, text="Submit", command=lambda: checkAns(o,ans.get())).grid(row=12, column=0,sticky="W")

        rootc.mainloop()
        
def read_db(t,c):
    global marks
    marks=0
    sql = "SELECT q_title, q_course FROM question"
    cursor.execute(sql)
    data = cursor.fetchall()
    count=0
    
    for row in data:
        if (t==row[0]):
            if(c==row[1]):
                exist=True
                #root.destroy()
                #answerQuiz(t,c)
                count += 1
    if (count>0):
        answerQuiz(t,c)
    elif (count<=0):
        tkMessageBox.showerror("INVALID DATA","NO SUCH QUIZ EXISTS")
        


def selectQuiz(a,b):
    global root
    root = Tk()
    root.title("Student's Portal")
    root.geometry("500x500")
    global n
    n=a
    global p
    p=b
    
    Label(root, text="Please enter the title and course for the quiz").grid(row=1, columnspan=2)
    Label(root, text="Title of the quiz").grid(row=2)
    Label(root, text="Course for the quiz").grid(row=3)

    title = Entry(root)
    title.grid(row=2,column=1)
    course = Entry(root)
    course.grid(row=3, column=1)

    b1=Button(root, text="Proceed", command=lambda: read_db(title.get(), course.get()))
    b1.grid(row=4, columnspan=2)

    root.mainloop()


#global root
#root=Tk()
#selectQuiz()
#root.mainloop()
                      
