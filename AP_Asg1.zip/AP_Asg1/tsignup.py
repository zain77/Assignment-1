from Tkinter import *
import tlogin
import MySQLdb
from tkMessageBox import *


#connect to database
db = MySQLdb.connect ("localhost", "root", "", "quizzles")
#setup the cursor
cursor = db.cursor()

def write_db(n,p):
    
    sql = "INSERT INTO teachers (t_uname, t_paswd) VALUES (%s,%s)"
    cursor.execute(sql, (n,p))
    
    cursor.close()
    db.close()
    showinfo("Succesful", "You may login now")
    

    
def signup():
    root = Tk()
    root.geometry("400x200")
    root.title("SIGNUP")
    
    l0 = Label(root, text="Please create a username and password")
    l1 = Label(root, text="CREATE USERNAME: ")
    uname = Entry(root) #take input from user
    l2 = Label(root, text="CREATE PASSWORD: ")
    upass = Entry(root, show="*") #take input from user but hide the input data

    l0.grid(row=0, columnspan=2)
    l1.grid(row=1, column=0, sticky=E)
    l2.grid(row=2, column=0, sticky=E)
    uname.grid(row=1, column=1)
    upass.grid(row=2, column=1)
        
    b1 = Button(root, text="Sign up", fg="red", bg="white", # create signup button
                command=lambda: write_db(uname.get(),upass.get()))
    b1.grid(row=4, columnspan=2)


    root.mainloop()




    
